#ifndef SPLASHKIT_DONE
// splashkit.h not safe to include multiple times (to fix)
#define SPLASHKIT_DONE
#include "splashkit.h"

// hacky way to disable music playing across the codebase (mp3 not supportd, to fix)
void dont_play_music(std::string name){}
void dont_play_music(music data){}
#define play_music dont_play_music
#endif