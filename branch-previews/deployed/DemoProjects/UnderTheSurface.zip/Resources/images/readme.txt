Place images in this folder. SplashKit can work with png, jpeg, jpg, or tif files.
