You can place bundle scripts in this folder.
